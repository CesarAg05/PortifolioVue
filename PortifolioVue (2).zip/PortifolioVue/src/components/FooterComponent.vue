<template>
    <Footer class="border bottom-0 w-full bg-black text-white text-center py-6">
        <p>Desenvolvido por César - Para o Trabalho com Vue</p>
    </Footer>

</template>