<template>
  <div class="bg-white p-20 rounded space-x-2">
    <img class="h max-w-xs" src="/assets/image/Captura de tela 2025-05-26 222253.png" alt="image description">
  </div>
</template>