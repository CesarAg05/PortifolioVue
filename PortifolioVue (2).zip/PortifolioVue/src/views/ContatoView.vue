<template>
    <div class="p-8 bg-gray-700 text-white text-4xl font-bold justify-center flex">
        <H1>Contate-me:</H1>
    </div>
    <div class="border-4 border-gray-700/100 p-4">
        <form class="max-w-sm mx-auto mt-4">
            <div class="mb-5">
                <label for="large-input" class="block mb-2 text-sm font-medium text-gray-900 dark:text-black">Email</label>
                <input type="text" id="large-input" class="block w-full p-4 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 text-base focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
            </div>
            <div class="mb-5">
                <label for="base-input" class="block mb-2 text-sm font-medium text-gray-900 dark:text-black">Assunto:</label>
                <input type="text" id="base-input" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
            </div>
            <div>
                <label for="small-input" class="block mb-2 text-sm font-medium text-gray-900 dark:text-black">Mensagem:</label>
                <input type="text" id="small-input" class="block w-full p-7 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 text-xs focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
            </div>
        </form>
    </div>
    <div class="bg-white rounded p-3 flex border-4 border-gray-700/100 mt-4">
        <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="45" height="100" viewBox="0 0 50 50">
            <path d="M12 23.403V23.39 10.389L11.88 10.3h-.01L9.14 8.28C7.47 7.04 5.09 7.1 3.61 8.56 2.62 9.54 2 10.9 2 12.41v3.602L12 23.403zM38 23.39v.013l10-7.391V12.41c0-1.49-.6-2.85-1.58-3.83-1.46-1.457-3.765-1.628-5.424-.403L38.12 10.3 38 10.389V23.39zM14 24.868l10.406 7.692c.353.261.836.261 1.189 0L36 24.868V11.867L25 20l-11-8.133V24.868zM38 25.889V41c0 .552.448 1 1 1h6.5c1.381 0 2.5-1.119 2.5-2.5V18.497L38 25.889zM12 25.889L2 18.497V39.5C2 40.881 3.119 42 4.5 42H11c.552 0 1-.448 1-1V25.889z"></path>
        </svg>
        <p class="flex mt-10 ml-3 font-bold">
            : crsaraugustonogueira@gmail.com
        </p>
    </div>

    <div class="bg-white rounded p-3 flex border-4 border-gray-700/100 mt-4">
        <svg width="45" height="100" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 3C5.1 3 6 3.9 6 5C6 6.1 5.1 7 4 7C2.9 7 2 6.1 2 5C2 3.9 2.9 3 4 3ZM2 21V8H6V21H2ZM9 8H13V10H13.1C13.6 9.2 14.7 8 16.5 8C19.4 8 21 9.9 21 13V21H17V14C17 12.7 16.3 12 15.2 12C14.1 12 13 12.8 13 14V21H9V8Z" fill="black"/>
            <a href="https://www.linkedin.com/in/cesar-augusto-40b05b237/"></a>
        </svg>
        <p class="flex mt-10 ml-3 font-bold">
            : Cesar Augusto
        </p>
    </div>

    <div class="bg-white rounded p-3 flex border-4 border-gray-700/100 mt-4">
        <svg width="45" height="100" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 2H7L10 8L7.5 10.5C8.9 13.1 10.9 15.1 13.5 16.5L16 14L22 17V21H19C10.7 21 3 13.3 3 5V2Z" fill="black"/>
        </svg>
        <p class="flex mt-10 ml-3 font-bold">
            : (18) 99630-0944
        </p>
    </div>
    
</template>